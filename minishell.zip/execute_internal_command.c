/* Documentation:
Name : Vishnu Murarisetty
Date : 19/08/2024
Title : Executing Internal Commands
*/

#include "main.h"

extern int status;    // External variable representing the last command's status
extern Slist *head;   // External pointer to the head of the linked list storing background processes

/*
 * Function: bg_handler
 * --------------------
 * Signal handler for background processes.
 *
 * Parameters:
 *   - signum: The signal number received.
 *   - info: Information about the signal (e.g., the PID of the process that sent the signal).
 *   - arg: Additional arguments (not used here).
 *
 * Description:
 *   - This function would typically handle the signal received when a background process changes state.
 *   - The commented-out code checks if the signal corresponds to a known process and prints the signal number.
 */
void bg_handler(int signum, siginfo_t *info, void *arg)
{
    // Placeholder for handling background process signals
    /* for(int j=0; arr[j]; j++)
       {
       if(arr[j] == info -> si_pid)
       {
           printf("signal -> %d \n",info -> si_signo);
           //    printf("Child Terminated with exit code %d\n",info -> si_status);
       }
       }*/
}

/*
 * Function: execute_internal_commands
 * -----------------------------------
 * Executes an internal shell command based on the input string.
 *
 * Parameters:
 *   - input_string: A pointer to a string containing the command and its arguments.
 *
 * Description:
 *   - This function handles several built-in shell commands such as "exit", "pwd", "cd", "echo", "fg", "jobs", and "bg".
 *   - Each command is matched with the input string, and the appropriate action is taken.
 */
void execute_internal_commands(char *input_string)
{
    if(strcmp(input_string, "exit") == 0)
    {
        // Exit the shell
	exit(0);
    }
    else if(strcmp(input_string, "pwd") == 0)
    {
        // Print the current working directory
	char path[100];
	getcwd(path, 100);
	printf("%s\n", path);
    }
    else if(strncmp(input_string, "cd", 2) == 0)
    {
        // Change the current directory
	char path[100];
	strcpy(path, input_string + 3);
	int ret = chdir(path);
	if(ret == -1)
	{
	    printf("Invalid Path!\n");
	}
    }
    else if(strncmp(input_string, "echo", 4) == 0)
    {
        // Handle echo command with special variables
	echo(input_string, status);
    }
    else if(strcmp(input_string, "fg") == 0)
    {
        // Bring the last background job to the foreground
	int stat;
	print_command(head);
	printf("\n");
	int pid = getlastpid(head);
	kill(pid, SIGCONT);
	waitpid(pid, &stat, WUNTRACED);
	del_last_node(&head);
    }
    else if(strcmp(input_string, "jobs") == 0)
    {
        // List all background jobs
	print_list(head);
    }
    else if(strcmp(input_string, "bg") == 0)
    {
        // Resume the last background job in the background
	int pid = getlastpid(head);
	// arr[i++] = pid;
	printf("[%d]+ ", pid);
	print_command(head);
	printf(" &\n");
	kill(pid, SIGCONT);
	del_last_node(&head);

	// Set up the signal handler for background processes
	struct sigaction new_act;
	memset(&new_act, 0, sizeof(new_act));
	new_act.sa_sigaction = bg_handler;
	new_act.sa_flags = SA_SIGINFO | SA_NOCLDWAIT;
	sigaction(SIGCHLD, &new_act, NULL);
    }
}

/*
 * Function: echo
 * --------------
 * Handles the echo command with special variables like $$, $?, and $SHELL.
 *
 * Parameters:
 *   - input_string: A pointer to a string containing the echo command and arguments.
 *   - status: The exit status of the last command executed.
 *
 * Description:
 *   - This function prints specific values based on the input string, such as the shell PID, 
 *     the last command's exit status, or the shell environment variable.
 */
void echo(char *input_string, int status)
{
    if(strcmp(input_string, "echo $$") == 0)
    {
        // Print the shell's PID
	printf("Minishell PID -> %d\n", getpid());
    }
    else if(strcmp(input_string, "echo $?") == 0)
    {
        // Print the last child process's exit status
	printf("Last child exit status -> %d\n", WEXITSTATUS(status));
    }
    else if(strcmp(input_string, "echo $SHELL") == 0)
    {
        // Print the shell environment variable
	printf("%s\n", getenv("SHELL"));
    }
}

/*
 * Function: getlastpid
 * --------------------
 * Retrieves the PID of the last process in the linked list.
 *
 * Parameters:
 *   - head: A pointer to the head of the linked list.
 *
 * Returns:
 *   - The PID of the last process in the list, or a failure code if the list is empty.
 *
 * Description:
 *   - This function traverses the linked list to find the last node and returns its PID.
 */
int getlastpid(Slist *head)
{
    if(head == NULL)
    {
	printf("List is empty check function\n");
	return failure;
    }
    while(head->next)
    {
	head = head->next;
    }
    return head->pid;
}

/*
 * Function: del_last_node
 * -----------------------
 * Deletes the last node from the linked list.
 *
 * Parameters:
 *   - head: A pointer to the pointer of the head of the linked list.
 *
 * Description:
 *   - This function removes the last node from the list and frees its memory.
 *   - If the list is empty or has only one node, it handles those cases accordingly.
 */
void del_last_node(Slist **head)
{
    if (*head == NULL)
    {
	printf("List is empty\n");
	return;
    }

    // If there is only one node in the list
    if ((*head)->next == NULL)
    {
	free(*head);
	*head = NULL;
	return;
    }

    Slist *prev = NULL;
    Slist *current = *head;

    // Traverse to the last node
    while (current->next != NULL)
    {
	prev = current;
	current = current->next;
    }

    // Delete the last node
    free(current);
    prev->next = NULL;
}

/*
 * Function: print_command
 * -----------------------
 * Prints the command stored in the last node of the linked list.
 *
 * Parameters:
 *   - head: A pointer to the head of the linked list.
 *
 * Description:
 *   - This function traverses the linked list to the last node and prints the stored command.
 */
void print_command(Slist *head)
{
    if(head == NULL)
    {
	printf("List is Empty\n");
	return;
    }
    while(head->next)
    {
	head = head->next;
    }
    printf("%s", head->command);
}

/*
 * Function: print_list
 * --------------------
 * Prints all the jobs in the linked list with their PIDs and commands.
 *
 * Parameters:
 *   - head: A pointer to the head of the linked list.
 *
 * Description:
 *   - This function traverses the linked list and prints the PID and command of each job in the list.
 */
void print_list(Slist *head)
{
    if(head == NULL)
    {
	printf("List is Empty\n");
	return;
    }
    while(head)
    {
	printf("[%d]+   stopped\t\t%s\n", head->pid, head->command);
	head = head->next;
    }
}

