/* Documentation:
Name : 	Vishnu Murarisetty
Date : 19/08/2024
Title : Minishell
 */

#include "main.h"

int main()
{
    char input_string[100];          // Buffer to hold the user's input command
    char prompt[100] = "minishell$"; // Shell prompt displayed to the user

    system("clear");                 // Clear the terminal screen
    scan_input(prompt, input_string); // Function to read user input
}

