/* Documentation:
Name : Vishnu Murarisetty
Date : 19/08/2024
Title : nPipe executing piped commands
 */

#include "main.h"

/*
 * Function: n_pipe
 * ----------------
 * Executes a series of piped commands.
 *
 * Parameters:
 *   - arg_vector: An array of strings representing the command and its arguments, where pipes ("|") separate different commands.
 *
 * Description:
 *   - The function identifies the positions of the commands separated by pipes.
 *   - It then sets up a pipeline to execute the commands in sequence, redirecting the output of one command to the input of the next.
 *   - For each command, a new process is forked, and the necessary file descriptors are set up for inter-process communication.
 *   - The function waits for the last command in the pipeline to finish.
 */
void n_pipe(char *arg_vector[])
{
    int cmd_pos[50];  // Array to store positions of commands in arg_vector
    int cmd_count = 0; // Counter for the number of commands
    int i = 0;         // Index for iterating through arg_vector
    
    // Initialize the position of the first command
    cmd_pos[0] = 0;
    cmd_count++;

    // Iterate through arg_vector to find positions of commands and nullify pipe symbols
    for (i = 0; arg_vector[i] != NULL; i++)
    { 
	if (strcmp(arg_vector[i], "|") == 0)
	{
	    cmd_pos[cmd_count++] = i + 1;  // Store the position of the next command
	    arg_vector[i] = NULL;          // Nullify the pipe symbol to separate commands
	}
    }

    int fd[2];   // File descriptors for the pipe
    int pid;     // Process ID for forked processes

    // Loop through each command and set up the pipeline
    for (i = 0; i < cmd_count; i++)
    {
	if (pipe(fd) == -1)
	{
	    perror("ERROR: PIPE IS NOT CREATED SUCCESSFULLY\n");
	    return;
	}

	pid = fork();  // Fork a new process

	if (pid == 0)  // Child process
	{
	    close(fd[0]);           // Close the read end of the pipe
	    if(i != cmd_count - 1)  // If not the last command, redirect output to pipe
		dup2(fd[1], 1);
	    execvp(arg_vector[cmd_pos[i]], &arg_vector[cmd_pos[i]]); // Execute command
	    exit(0);               // Exit child process
	}
	else if (pid > 0)  // Parent process
	{
	    close(fd[1]);          // Close the write end of the pipe
	    dup2(fd[0], 0);        // Redirect input to read from pipe
	}
    }
    
    // Wait for the last command in the pipeline to finish
    waitpid(pid, NULL, WUNTRACED);
}

