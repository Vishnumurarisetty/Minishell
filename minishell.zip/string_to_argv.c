/* Documentation:
Name : Vishnu Murarisetty
Date : 19/08/2024
Title : String to argv
 */

#include "main.h"

/*
 * Function: str_to_args
 * ---------------------
 * Converts an input string into an array of arguments.
 *
 * Parameters:
 *   - input_string: The input string containing the command and its arguments.
 *
 * Returns:
 *   - A pointer to an array of strings (arguments), with each element representing a separate argument.
 *
 * Description:
 *   - The function splits the input string into arguments based on spaces and stores each argument in the array `argv`.
 *   - Memory is allocated dynamically for the array and each argument.
 */
char **str_to_args(char *input_string)
{
    char **argv = calloc(20, sizeof(char *));  // Allocate memory for an array of 20 pointers to strings
    int j = 0, k = 0;                          // j: index for arguments, k: index for characters within an argument
    argv[0] = malloc(100);                     // Allocate memory for the first argument

    for (int i = 0; input_string[i]; i++)      // Loop through each character in the input string
    {
        if (input_string[i] != ' ')            // If the character is not a space, add it to the current argument
        {
            argv[j][k++] = input_string[i];    // Store the character in the current argument
        }
        else
        {
            argv[j][k] = '\0';                 // Null-terminate the current argument
            j++;                               // Move to the next argument
            argv[j] = malloc(100);             // Allocate memory for the new argument
            k = 0;                             // Reset the character index for the new argument
        }
    }
    argv[j][k] = '\0';                         // Null-terminate the last argument

    return argv;                               // Return the array of arguments
}

