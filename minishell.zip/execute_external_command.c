/* Documentation:
Name : Vishnu Murarisetty
Date : 19/08/2024
Title : Executing External Commands
*/

#include "main.h"

/*
 * Function: execute_external_commands
 * -----------------------------------
 * Executes an external command provided as input.
 *
 * Parameters:
 *   - input_string: A pointer to a string containing the command and its arguments.
 *
 * Description:
 *   - The function converts the input string into an array of arguments.
 *   - It checks whether the command contains a pipe ("|").
 *   - If no pipe is present, the command is executed using execvp.
 *   - If a pipe is present, the function calls n_pipe (or another function, depending on implementation) to handle the piped command.
 *   - An error message is printed if command execution fails.
 */
void execute_external_commands(char *input_string)
{
    // Convert the input string to an array of arguments
    char **argv = str_to_args(input_string);
    char pipe_flag = 0;

    // Check if the command contains a pipe ("|")
    for(int i = 0; argv[i]; i++)
    {
	if(strcmp("|", argv[i]) == 0)
	{
	    pipe_flag = 1;
	    break;
	}
    }

    // If no pipe is present, execute the command directly
    if(!pipe_flag)
    {
	if(execvp(argv[0], argv) == -1)
	{
	    printf("ERROR: Command execution failed\n");
	}
    }
    // If a pipe is present, handle the piped command
    else
    {
	// n_pipe is assumed to handle commands with pipes
	// Replace with execute_with_npipe(argv) if needed
	n_pipe(argv);
    }

    printf("External command\n");
}

