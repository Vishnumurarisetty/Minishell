/* Documentation:
Name : Vishnu Murarisetty
Date : 19/08/2024
Title : Check command type
 */

#include "main.h"

/*
 * Function: check_command_type
 * ----------------------------
 * Determines the type of command passed to the function.
 *
 * Parameters:
 *   - command: A pointer to a string representing the command to be checked.
 *
 * Returns:
 *   - BUILTIN: If the command is one of the built-in shell commands.
 *   - EXTERNAL: If the command is an external command listed in the external_commands.txt file.
 *   - NO_COMMAND: If the command is not recognized.
 *   
 * Description:
 *   - If the command starts with "./", it is considered an executable file and is executed.
 *   - If the command matches one of the built-in shell commands, BUILTIN is returned.
 *   - If the command matches an external command listed in external_commands.txt, EXTERNAL is returned.
 *   - If the command is not recognized, NO_COMMAND is returned.
 */
int check_command_type(char *command)
{
    // Check if the command starts with "./"
    if (strncmp(command, "./", 2) == 0) {
	// Remove the newline character at the end of the command string, if present
	command[strcspn(command, "\n")] = 0;

	int ex_pid = fork();
	int check;

	if (ex_pid > 0) {
	    // Parent process: wait for the child process to finish
	    waitpid(ex_pid, &check, WUNTRACED);
	} else if (ex_pid == 0) {
	    // Child process: execute the command
	    execlp(command, command, NULL);
	    // If execlp fails, print an error message and exit the child process
	    perror("execlp");
	    _exit(1);  // Use _exit to avoid issues with stdio buffer sharing
	} else {
	    // Handle fork failure
	    perror("fork");
	}
    }
    else 
    {
	// List of built-in commands
	char *builtins[] = {"fg", "bg", "jobs", "echo", "printf", "read", "cd", "pwd", "pushd", "popd", "dirs", "let", "eval", "set", "unset", "export", "declare", "typeset", "readonly", "getopts", "source", "exit", "exec", "shopt", "caller", "true", "type", "hash", "bind", "help", NULL};
	
	// Check if the command matches any built-in command
	for(int i = 0; builtins[i] != NULL; i++)
	{
	    if(strcmp(command, builtins[i]) == 0)
		return BUILTIN;
	}
	
	// Open the file containing external commands
	int fd = open("/home/vishnu/23036/minishell_vishnu/external_commands.txt", O_RDONLY);
	char ch, buff[50];
	int i = 0, flag = 0;
	
	// Read the file to check for external commands
	while(read(fd, &ch, 1))
	{
	    if(ch != '\n')
	    {
		buff[i++] = ch;
	    }
	    else
	    {
		buff[i] = '\0';
		i = 0;
		flag = 1;
	    }
	    
	    // Check if the command matches any external command
	    if(flag == 1)
	    {
		if(strcmp(command, buff) == 0)
		{
		    close(fd);
		    return EXTERNAL;
		}
	    }
	}
	
	// Close the file
	close(fd);
	
	// Return NO_COMMAND if the command does not match any known command
	if(strncmp(command, "PS1", 3) != 0)
	    return NO_COMMAND;
    }
}

