/* Documentation:
Name : Vishnu Murarisetty
Date : 19/08/2024
Title : Scan Input
 */

#include "main.h"

int status;         // Stores the status of the last executed command
int pid;            // Process ID of the forked child process
int flag = 0;       // Flag to indicate if a command is running in the foreground
int pipe_fd[2];     // File descriptors for pipe communication
char cmd[100];      // Buffer to store the current command
Slist *head = NULL; // Head of the singly linked list to manage background jobs

/*
 * Function: signal_handler
 * ------------------------
 * Handles signals like SIGINT (Ctrl+C) and SIGTSTP (Ctrl+Z).
 *
 * Parameters:
 *   - sig_num: The signal number.
 *
 * Description:
 *   - SIGINT is ignored.
 *   - SIGTSTP either ignores the signal or stops the foreground process and adds it to the background job list.
 */
void signal_handler(int sig_num)
{
    if (sig_num == SIGINT)
    {
        signal(SIGINT, SIG_IGN);  // Ignore SIGINT (Ctrl+C)
    }
    if (sig_num == SIGTSTP)
    {
        if (flag == 0)
        {
            signal(SIGTSTP, SIG_IGN);  // Ignore SIGTSTP (Ctrl+Z) if no foreground process
        }
        else
        {
            flag = 0;
            char input_string[100];

            printf("hello\n");
            insert_at_last(&head, cmd); // Add the command to the background job list
            printf("hello\n");
            print_last(head);           // Print the last added background job
        }
    }
}

/*
 * Function: scan_input
 * --------------------
 * Scans and processes user input in a loop, handling signals and executing commands.
 *
 * Parameters:
 *   - prompt: The shell prompt string.
 *   - input_string: Buffer to store the user input.
 *
 * Description:
 *   - The function reads input, checks if it's a built-in or external command, and executes it accordingly.
 *   - Handles special cases like changing the prompt and signal management.
 */
void scan_input(char *prompt, char *input_string)
{
    signal(SIGINT, signal_handler);   // Set signal handler for SIGINT
    signal(SIGTSTP, signal_handler);  // Set signal handler for SIGTSTP
    int check = 0;

    while (1)
    {
        input_string[0] = '\0';	
        if (check >= 0)
            printf(ANSI_COLOR_GREEN "%s " ANSI_COLOR_RESET, prompt);  // Print the prompt
        check = scanf("%[^\n]", input_string); // Read the input until newline
        __fpurge(stdin);  // Clear the input buffer

        if (strncmp(input_string, "PS1", 3) == 0) // Change the prompt if input is PS1
        {
            if (strstr(input_string, " "))
            {
                printf("Command not found\n");
            }
            else
            {
                strcpy(prompt, input_string + 4); // Update the prompt
            }
        }

        if (input_string[0] == '\0') // Continue if no input
        {
            continue;
        }

        char *ch = get_command(input_string); // Extract the command from the input
        int ret = check_command_type(ch); // Check if it's a built-in or external command

        if (ret == EXTERNAL)
        {
            flag = 1;
            pid = fork(); // Fork a new process

            if (pid > 0) // Parent process
            {
                strcpy(cmd, input_string); // Store the command
                waitpid(pid, &status, WUNTRACED); // Wait for the child process
            }
            else if (pid == 0) // Child process
            {
                signal(SIGINT, SIG_DFL); // Set default action for SIGINT
                execute_external_commands(input_string); // Execute external command
                exit(0); // Exit the child process
            }

            if (pipe(pipe_fd) == -1) // Create a pipe for communication
            {
                perror("pipe");
                exit(EXIT_FAILURE);
            }
        }
        else if (ret == BUILTIN)
        {
            execute_internal_commands(input_string); // Execute built-in command
        }

        memset(input_string, '\0', 100); // Clear the input buffer
    }
}

/*
 * Function: get_command
 * ---------------------
 * Extracts the command part from the input string.
 *
 * Parameters:
 *   - input_string: The input string containing the command and arguments.
 *
 * Returns:
 *   - A pointer to a string containing the extracted command.
 */
char *get_command(char *input_string)
{
    char *arr = malloc(20);
    char temp[100];
    strcpy(temp, input_string);

    for (int i = 0; i < strlen(input_string); i++)
    {
        if (temp[i] == ' ')
        {
            temp[i] = '\0'; // Null-terminate the command string
            break;
        }
    }

    strcpy(arr, temp); // Copy the command to the allocated memory
    return arr;
}

/*
 * Function: insert_at_last
 * ------------------------
 * Inserts a new node at the end of the linked list.
 *
 * Parameters:
 *   - head: Pointer to the head of the linked list.
 *   - input_string: The command string to store in the list.
 *
 * Returns:
 *   - success or failure status.
 */
int insert_at_last(Slist **head, char *input_string)
{
    Slist *new = malloc(sizeof(Slist)); // Allocate memory for the new node
    if (new == NULL)
    {
        return failure; // Return failure if allocation fails
    }
    new->pid = pid; // Set the process ID for the new node
    new->next = NULL;
    strcpy(new->command, input_string); // Store the command in the new node

    if (*head == NULL) // If the list is empty, set the new node as the head
    {
        *head = new;
        return success;
    }

    Slist *temp = *head;
    while ((temp->next) != NULL)
    {
        temp = temp->next; // Traverse to the last node
    }
    temp->next = new; // Insert the new node at the end
    return success;
}

/*
 * Function: print_last
 * --------------------
 * Prints the last command stored in the linked list.
 *
 * Parameters:
 *   - head: Pointer to the head of the linked list.
 */
void print_last(Slist *head)
{
    if (head == NULL)
    {
        printf("ERROR : Check inserting once\n");
        return;
    }
    while (head->next) // Traverse to the last node
    {
        head = head->next;
    }
    printf("[%d]+   stopped\t\t%s\n", head->pid, head->command); // Print the last command
}

